package com.example.ocihandson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OcihandsonApplicationTests {

	@Test
	void contextLoads() {
	}

}
