package com.example.ocihandson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OcihandsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(OcihandsonApplication.class, args);
	}

}
